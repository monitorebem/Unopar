
<?
//https://suaempresanapalmadamao.com.br/envio/envio.php?or=22011002&de=01310930&al=4&la=12&co=17&pe=2

$origem =$_GET['or'];
$destino=$_GET['de'];
$altura=$_GET['al']; //cm
$largura=$_GET['la']; //cm
$comprimento=$_GET['co'];//cm
$peso=$_GET['pe'];; //kg


// URL para a requisição cURL
$url = "https://viacep.com.br/ws/".$origem."/json/";

// Iniciando o cURL
$curl = curl_init($url);

// Configurações do cURL
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); // Retorna o resultado em vez de imprimir
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true); // Seguir redirecionamentos, se houver

// Executando o cURL e obtendo o resultado
$response = curl_exec($curl);

// Decodificar o JSON para um array associativo
$data = json_decode($response, true);

// Exibir cada chave e valor em uma linha separada
echo"ORIGEM#";
echo "CEP: ".$data['cep']."#";
echo "AV/Rua: ".$data["logradouro"]."#";
echo "Bairro: ".$data["bairro"]."#";
echo "Cidade: ".$data["localidade"]."#";
echo "UF: ".$data["uf"]."#";
echo "Estado: ".$data["estado"]."#";
echo "Região: ".$data["regiao"]."#";
echo "DDD: ".$data["ddd"]."#";

// URL para a requisição cURL
$url = "https://viacep.com.br/ws/".$destino."/json/";

// Iniciando o cURL
$curl = curl_init($url);

// Configurações do cURL
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); // Retorna o resultado em vez de imprimir
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true); // Seguir redirecionamentos, se houver

// Executando o cURL e obtendo o resultado
$response = curl_exec($curl);

// Decodificar o JSON para um array associativo
$data = json_decode($response, true);

// Exibir cada chave e valor em uma linha separada
echo"#DESTINO#";
echo "CEP: ".$data['cep']."#";
echo "AV/Rua: ".$data["logradouro"]."#";
echo "Bairro: ".$data["bairro"]."#";
echo "Cidade: ".$data["localidade"]."#";
echo "UF: ".$data["uf"]."#";
echo "Estado: ".$data["estado"]."#";
echo "Região: ".$data["regiao"]."#";
echo "DDD: ".$data["ddd"]."#";

echo"#EMBALAGEM#";
echo "Altura: ".$altura." cm #";
echo "Largura: ".$largura." cm #";
echo "Comprimento: ".$comprimento." cm #";
echo "Peso: ".$peso." Kg #";
?>


