
<?
//https://suaempresanapalmadamao.com.br/envio/envio.php?or=22011002&de=01310930&al=4&la=12&co=17&pe=2

echo "<b>API ViaCep + Api Melhor Envio, para auxiliar no seu transporte de encomendas<br></b><br>"; 

$origem =$_GET['or'];
$destino=$_GET['de'];
$altura=$_GET['al']; //cm
$largura=$_GET['la']; //cm
$comprimento=$_GET['co'];//cm
$peso=$_GET['pe'];; //kg


// URL para a requisição cURL
$url = "https://viacep.com.br/ws/".$origem."/json/";

// Iniciando o cURL
$curl = curl_init($url);

// Configurações do cURL
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); // Retorna o resultado em vez de imprimir
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true); // Seguir redirecionamentos, se houver

// Executando o cURL e obtendo o resultado
$response = curl_exec($curl);

// Decodificar o JSON para um array associativo
$data = json_decode($response, true);

// Exibir cada chave e valor em uma linha separada
echo"<B>ORIGEM<B><br><Br>";
echo "CEP: ".$data['cep']."<br>";
echo "AV/Rua: ".$data["logradouro"]."<br>";
echo "Bairro: ".$data["bairro"]."<br>";
echo "Cidade: ".$data["localidade"]."<br>";
echo "UF: ".$data["uf"]."<br>";
echo "Estado: ".$data["estado"]."<br>";
echo "Região: ".$data["regiao"]."<br>";
echo "DDD: ".$data["ddd"]."<br>";

// URL para a requisição cURL
$url = "https://viacep.com.br/ws/".$destino."/json/";

// Iniciando o cURL
$curl = curl_init($url);

// Configurações do cURL
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); // Retorna o resultado em vez de imprimir
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true); // Seguir redirecionamentos, se houver

// Executando o cURL e obtendo o resultado
$response = curl_exec($curl);

// Decodificar o JSON para um array associativo
$data = json_decode($response, true);

// Exibir cada chave e valor em uma linha separada
echo"<br><br><B>DESTINO<B><br><Br>";
echo "CEP: ".$data['cep']."<br>";
echo "AV/Rua: ".$data["logradouro"]."<br>";
echo "Bairro: ".$data["bairro"]."<br>";
echo "Cidade: ".$data["localidade"]."<br>";
echo "UF: ".$data["uf"]."<br>";
echo "Estado: ".$data["estado"]."<br>";
echo "Região: ".$data["regiao"]."<br>";
echo "DDD: ".$data["ddd"]."<br>";

echo"<br><br><B>EMBALAGEM<B><br><Br>";
echo "Altura: ".$altura." cm <br>";
echo "Largura: ".$largura." cm <br>";
echo "Comprimento: ".$comprimento." cm <br>";
echo "Peso: ".$peso." Kg <br>";
echo "<br><Br><b>Resultado da pesquisa:</b><br><br>";

$url = "https://www.melhorenvio.com.br/api/v2/me/shipment/calculate";
$token = "eyJhdWQiOiIxIiwianRpIjoiZmVkOTYwMjkzYTY0YmZlZTA1NjczNTEyODc3YzJhODdmZmI1MGJkZjI0N2EwNWFmMTZiM2UyZDFkYWUzMDI4YzYwZTJjYWJlZTM0MGUxMWUiLCJpYXQiOjE3Mjc3MzUzODcuNTM1NTIzLCJuYmYiOjE3Mjc3MzUzODcuNTM1NTI1LCJleHAiOjE3NTkyNzEzODcuNTIxMDgyLCJzdWIiOiJlNTI5NDE0My0yYTUzLTQxYTgtYTIxZC0wODBhNTlhYTZmMzMiLCJzY29wZXMiOlsic2hpcHBpbmctY2FsY3VsYXRlIl19.PsEwzNBOtkuwljyZ1bUm5x1LKBejtiPDoTZHE4fryJiCmlVEc4Bh9L_Ga46P2rzX1EQ-f-euepMMwrugApaSaC87gBdcmfqeYfPenJeRTeAxGoHRfg1mHsZB3RwcqiZbpMhlhU4-dXdzPqlSLrbnH_9m7qe1OWdR45PToYdc8rj9xOwtxyzA0_NCkdOiYGicF5QUHZSaMnFASyC2Nv7nYhLGFCl5j-P6gYAqTouTnHoomROfikOPiKwqxEfGFdP_6lNfMGrRIpuorNlu9TCXjm1OfCSfrYbCeeSS2JdHo4lvDlW7OjLc9_3DOEvucQm6TwBNCVgpqmiOK1oSqx2kLdidXdcId8rHWS8G3CwrARAbWG5iUMFZRC6mu_Efz03Y3GdgSWMem_XwYLziRcBvk0RPTRo-KxqBt5rTzro6QtPhMae5sUfn6xWT-DUL72dsovZ9l63jcjwRcShJzzUAjIVWwAMPwYPCfUKnrfKEf6ALajDJsdBzgh1kWw8ryRq3fZ_LqTu0trwCvneHVaKnXOHBkXRh4UmyB1Y40QNnXlN6E7z7zFMj5fOtq2FcnJf2UFL-9oejmKsdlHY3Uqq51F1SizAekMF4OedWouRcnuiiqtzLxYqv-avxbIb-5ZjHfmZhU6ZIDXVFd9jAe80Z47JQTeYoPYLY7v-U0KVsmmE";


$dados_json = '{"from": {"postal_code": '.$origem.'},"to": {"postal_code": "'.$destino.'"},"package": {"height": '.$altura.',"width": '.$largura.',"length": '.$comprimento.',"weight": '.$peso.'}}';

$headers = [
    "Content-Type: application/json",
    "Authorization: Bearer " . $token,
    "User-Agent: Aplicação suaempresanapalmadamao@gmail.com",
    "Accept: application/json"
];


$ch = curl_init();


curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $dados_json);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);


$resultados = curl_exec($ch);

$fim =  json_decode($resultados);  

foreach ($fim as $item) {
    if($item->price !=''){
    // Exibindo os resultados em formato simples, um abaixo do outro
    echo "<img src=". $item->company->picture." height = 80><br>";
    echo "Tipo: " . $item->name . "<br>";
    echo "Preço: R$" . $item->price . "<br>";
    echo "Desconto: R$" . $item->discount . "<br>";
    echo "Tempo de entrega: " . $item->delivery_time . " dias<br><br>";
}
}
//var_dump($fim);
//echo "<br><br><br>";
//var_dump($resultados);

//echo "Total de empresas:".$cnt;
curl_close($ch);

echo "<br><br> Projeto de Extensão Unopar - Targino Soares da Silva<br><br>"
?>


